
%% nonsymmetric 2D steady-state SFDE 
clc
clear;
d1=50;
d2=10;
e1=20;
e2=30;

alpha=1.01;
beta=1.01;

for i=7: 2: 9
n=2^i-1
h=1/(n+1)
x=0:h:1;
y=x;
tao=1/ceil(n^alpha);
% tao=1/n;
mu=(h^(alpha))/tao; 

f1=[];
for i = 1:n
    for j = 1:n
        f1(i,j)=100*sin(10*x(i)).*cos(y(j))+sin(10*tao).*x(i).*y(j);
    end
end
f=tao*f1(:);%RHS
DoF=size(f);
NN=DoF(1)
x0 = ones(NN,1)/sqrt(NN);
% yf=flip(f);
%% construct matrix A %%%%%%%%%%%%%%%
gx=-get_Tseries(alpha,n);%1ST order SGD
gy=-get_Tseries(beta,n);

cLx=-gx(2:n+1);
rLx=-[gx(2) gx(1) zeros(1,n-2)];

cLy=-gy(2:n+1);
rLy=-[gy(2) gy(1) zeros(1,n-2)];

cL_alpha=tao/(h^alpha)*(d1*cLx+d2*rLx'); %the first column of L_alpha 
rL_alpha=tao/(h^alpha)*(d1*rLx+d2*cLx'); %the first row of L_alpha

cL_beta=tao/(h^beta)*(e1*cLy+e2*rLy'); %the first column of L_alpha 
rL_beta=tao/(h^beta)*(e1*rLy+e2*cLy'); %the first row of L_alpha
%% %% construct matrix P %%%%%%%%%%%%%%%

%% L is a laplace matrix
cL=[2;-1;zeros(n-2,1)]; % the first column of cT
rL=cL';
%% T2 is a symmetric toeplitz matrix
cLa=cLx+rLx'; %the first column 
cLb=cLy+rLy'; %the first column 
%% hankel matrix is construced by SPD T2
cHCLa=[cLa(3:n)' 0 0]';
cHCLb=[cLb(3:n)' 0 0]';
rHCLa=fliplr(cHCLa');
rHCLb=fliplr(cHCLb');
%% construct Tau
cTauLa=cLa-cHCLa; %the first column of Tau
cTauLb=cLb-cHCLb;
%% main
Dc=zeros(n,1);
for j=1:n
    Dc(j)=sqrt(2/(n+1))*sin((pi*j)/(n+1));
end
lam_L=(1./Dc).*(sqrt(2/(n+1))*dst(cL));
lam_alpha=(1./Dc).*(sqrt(2/(n+1))*dst(cTauLa));

lam_beta=(1./Dc).*(sqrt(2/(n+1))*dst(cTauLb));
lam_a=(tao/(h^alpha))*(((d1-d2)^2*lam_L.^alpha+d1*d2*lam_alpha.^2).^(0.5));
lam_b=(tao/(h^beta))*(((e1-e2)^2*lam_L.^beta+e1*e2*lam_beta.^2).^(0.5));

lam=1./(kron(ones(n,1),lam_a+ones(n,1))+kron(lam_b,ones(n,1)));

F=reshape(f,n,n);
F=flip(F);
F=fliplr(F);
rhs=F(:);
% ut=inv(YM)*rhs;
tic
u = minres(@(av)afun_NON_2D(cL_alpha,rL_alpha,cL_beta,rL_beta,av,n),rhs,1e-8,1000,@(tv)tfun_NON_2D(lam,tv,n),[],x0);
toc
% n_e=norm(u-ut,inf)


















Mat_Lx = toeplitz(cLx,rLx);
Pre_Lx = (Mat_Lx + Mat_Lx')/2;
Temp_vec = Pre_Lx(:,1);

Tau_sym_Lx = zeros(n,n);

for i = 1:n
    for j = 1:n
        if (i+j < n)
            Tau_sym_Lx(i,j) = Temp_vec(abs(j-i)+1) - Temp_vec(i+j+1);
        elseif (i+j == n || i+j == n+1 || i+j == n+2)
            Tau_sym_Lx(i,j) = Temp_vec(abs(j-i)+1);
        else
            Tau_sym_Lx(i,j) = Temp_vec(abs(j-i)+1) - Temp_vec((2*n+2-(i+j))+1);
        end
    end
end



Mat_Ly = toeplitz(cLy,rLy);
Pre_Ly = (Mat_Ly + Mat_Ly')/2;
Temp_vec = Pre_Ly(:,1);

Tau_sym_Ly = zeros(n,n);

for i = 1:n
    for j = 1:n
        if (i+j < n)
            Tau_sym_Ly(i,j) = Temp_vec(abs(j-i)+1) - Temp_vec(i+j+1);
        elseif (i+j == n || i+j == n+1 || i+j == n+2)
            Tau_sym_Ly(i,j) = Temp_vec(abs(j-i)+1);
        else
            Tau_sym_Ly(i,j) = Temp_vec(abs(j-i)+1) - Temp_vec((2*n+2-(i+j))+1);
        end
    end
end




% P_mat = eye(NN) + kron( eye(n), tao/(h^alpha)*(d1 + d2) * Tau_sym_Lx) + kron(tao/(h^beta)*(e1 + e2) * Tau_sym_Ly, eye(n));
% A = eye(NN) + kron( eye(n), tao/(h^alpha)*(d1*Mat_Lx + d2*Mat_Lx') ) + kron(tao/(h^beta)*(e1*Mat_Ly + e2*Mat_Ly'), eye(n));
% 
% figure
% plot(eig(inv(P_mat)*flip(A)),0,'k.')



col_Tau_sym_Lx = tao/(h^alpha)*(d1 + d2) * Tau_sym_Lx(:,1);
col_Tau_sym_Ly = tao/(h^beta)*(e1 + e2) * Tau_sym_Ly(:,1);


lam_alpha=(1./Dc).*(sqrt(2/(n+1))*dst(col_Tau_sym_Lx));
lam_beta=(1./Dc).*(sqrt(2/(n+1))*dst(col_Tau_sym_Ly));



lam_sym=1./(kron(ones(n,1),lam_alpha+ones(n,1))+kron(lam_beta,ones(n,1)));


tic
u = minres(@(av)afun_NON_2D(cL_alpha,rL_alpha,cL_beta,rL_beta,av,n),rhs,1e-8,1000,@(tv)tfun_NON_2D(lam_sym,tv,n),[],x0);
toc
end

% tic
% u = minres(@(av)afun_NON_2D(cL_alpha,rL_alpha,cL_beta,rL_beta,av,n),rhs,1e-8,1000,P_mat,[],x0);
% toc

% 
% tic
% u = minres(@(av)afun_NON_2D(cL_alpha,rL_alpha,cL_beta,rL_beta,av,n),rhs,1e-8,100,[],[],x0);
toc