function y2 = toepAvec(eign_A,x)
% Toeplitz-vector multiplication, i.e., const*A*x
% Input:  
%         eign_A -> The eignvalues of the Circulant matrix embedded by space Toeplitz matrix const*A
%              x -> The input column vector with length (N - 1)
% Output:     
%              y -> The fast Toeplitz-vector multiplication: const*A*x

n = length(x);

y = zeros(2*n,1);
y(1:n) = x;
y = ifft(eign_A.*fft(y));
% const*A*x
% y = real(y(1:n)); 
y2 = y(1:n);

end