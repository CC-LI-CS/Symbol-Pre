function [t, it, rv, dof, runt] = main_Run
% Example 3, Table 5.6 from J. Pestana, Preconditioners for symmetrized 
% Toeplitz and multilevel Toeplitz matrices, 2018.
%
% Outputs:
%   t: Array of CPU times
%   it: Array of iterations
%   rv: Array of relative residuals
%   dof: Degrees of freedom
%   runt: Runtime per grid size

addpath(genpath('../smt'));
addpath(genpath('../sptoeplitz'));

% Problem specifications
R = [1, 1];      % Right end of spatial interval
L = [0, 0];      % Left end of spatial interval
T = 1;           % Right end of time interval
dv = [50, 10];   % Diffusion coefficients in x direction
ev = [20, 30];   % Diffusion coefficients in y direction

% Fractional diffusion orders
fraclist = [1.1, 1.1];

gvec = (2.^(7)) - 1; % Problem dimensions
mtstep = 1;        % Number of time steps

n_time = gvec(end);
n_grid = length(gvec);
n_type = 6;
n_fracs = size(fraclist, 1);

% Initialize result storage
t = zeros(n_grid, n_type, n_fracs);
it = zeros(n_grid, n_time, n_type, n_fracs);
rv = zeros(n_grid, n_type, n_fracs);
dof = zeros(n_grid, n_fracs);
runt = zeros(n_grid, 1);

tol = 1e-8; % Solver tolerance

% Iterate over different grid sizes
for gr = 1:n_grid
    N = [gvec(gr), gvec(gr)]; % Grid in x and y directions
    num_levels = log2(gvec(gr) + 1);
    mg_levels = num_levels - 3; % Multigrid levels
    
    NN = N(1) * N(2);
    x0 = ones(NN, 1) / sqrt(NN); % Initial guess
        
    % Iterate over different fractional orders
    for k = 1:n_fracs
        alph = fraclist(k, 1); % Fractional diffusion power in x
        beta = fraclist(k, 2); % Fractional diffusion power in y
        M = ceil(N(1)^alph);   % Total number of time steps
        % tao=1/M;
        fprintf('N1= %i, N2 = %i, M = %i, alpha = %g, beta = %g\n', N, M, alph, beta);
        
        % Build matrices
        fprintf('Building matrices...\n')
        [Axsmt,Aysmt,u0, F] = Ex2_Gen_Toep(L, R, T, N, M, mtstep, alph, beta, dv, ev);
        Axsmtmult = toeprem(Axsmt);
        Aysmtmult = toeprem(Aysmt);
        dof(gr, k) = numel(F);
        fprintf('Done\n');
        
        % MINRES with symmetrized positive definite preconditioner
        fprintf('MINRES Circ...\n')
        u_old = u0;
        U5 = zeros(NN, mtstep);
        tic;
        Cx = smtcprec('strang', Axsmt); 
        Cpx = smcirc(ifft(abs(fft(Cx(:, 1)))));
        Cy = smtcprec('strang', Aysmt); 
        Cpy = smcirc(ifft(abs(fft(Cy(:, 1)))));
        eCpx = fft(Cpx(:, 1)); 
        eCpy = fft(Cpy(:, 1));
        for ts = 1:mtstep
            yb = flipud(F(:, ts) + u_old);
%%
            [u_old, ~, ~, itmr] = minres(@(x)ymtimes(Axsmtmult, Aysmtmult, N, x), yb, tol, 1000, @(x)applyP1pos(eCpx, eCpy, N, x), [], x0);
            U5(:, ts) = u_old;
            it(gr, ts, 5, k) = itmr;
        end
        t(gr, 5, k) = toc;
        rv(gr, 5, k) = norm(matvecmult(Axsmtmult, Aysmtmult, N, U5(:, 1)) - (F(:, 1) + u0), 'fro');
        fprintf('Done\n');
        
        % MINRES with MG preconditioner
        fprintf('MINRES MG...\n')
        u_old = u0;
        U6 = zeros(NN, mtstep);
        tic;
        IAx = full(eye(N(1))/2 - (Axsmt + Axsmt')/2);
        IAy = full(eye(N(1))/2 - (Aysmt + Aysmt')/2);
        [diagel, Lm, IIm, IAxm, IAym] = vcycle_2d_setup(IAx, IAy, mg_levels);
        for ts = 1:mtstep
            yb = flipud(F(:, ts) + u_old);
            [u_old, ~, ~, itmr] = minres(@(x)ymtimes(Axsmtmult, Aysmtmult, N, x), yb, tol, 1000, @(y)vcycle_2d(IAxm, IAym, IIm, diagel, Lm, y, 4, 4, 1, mg_levels, 0.9), [], x0);
            U6(:, ts) = u_old;
            it(gr, ts, 6, k) = itmr;
        end
        t(gr, 6, k) = toc;
        rv(gr, 6, k) = norm(matvecmult(Axsmtmult, Aysmtmult, N, U6(:, 1)) - (F(:, 1) + u0), 'fro');
        fprintf('Done\n');
        
        % Save and trim results
        it(:, mtstep+1:end, :, :) = [];
        save Ex2_Alpha t it rv runt dof gvec
    end
end

% Generate results table
fid = fopen('Ex2_Alpha.txt', 'w+');
for k = 1:n_fracs
    fprintf(fid, '\\hline\n');
    fprintf(fid, '\\multirow{%i}{*}{(%g,%g)} ', n_grid, fraclist(k, :));
    for j = 1:n_grid
        fprintf(fid, '& %i ', gvec(j)^2);
        fprintf(fid, '& %i & (%3.2g) & %i & (%3.2g) & %i & (%3.2g)', max(it(j, :, 1, k)), t(j, 1, k)/mtstep, max(it(j, :, 2, k)), t(j, 2, k)/mtstep, max(it(j, :, 3, k)), t(j, 3, k)/mtstep);
        fprintf(fid, '& %i & (%3.2g) & %i & (%3.2g) & %i & (%3.2g)', max(it(j, :, 4, k)), t(j, 4, k)/mtstep, max(it(j, :, 5, k)), t(j, 5, k)/mtstep, max(it(j, :, 6, k)), t(j, 6, k)/mtstep);
        fprintf(fid, '\\\\\n');
    end
end
fclose(fid);

end

% Helper functions

% Matrix-vector product with Toeplitz matrix
function y = matvecmult(Axsmtmult, Aysmtmult, N, x)
X = reshape(x, N(2), N(1));
y = reshape(X - mtimes(Axsmtmult, X) - mtimes(Aysmtmult, X')', N(1) * N(2), 1);
end

% Matrix-vector product with flipped Toeplitz matrix
function y = ymtimes(Axsmtmult, Aysmtmult, N, x)
X = reshape(x, N(2), N(1));
y = flipud(reshape(X - mtimes(Axsmtmult, X) - mtimes(Aysmtmult, X')', N(1) * N(2), 1));
end

% Apply positive definite circulant preconditioner
function y = applyP1pos(eCpx, eCpy, N, x)
X = reshape(x, N(2), N(1));
U = ifft(ifft(X')');
v = ones(N(1) * N(2), 1) + repmat(eCpx, N(2), 1) + kron(eCpy, ones(N(1), 1));
W = U ./ reshape(v, N(2), N(1));
Y = fft(fft((reshape(W, N(2), N(1)))')');
y = reshape(Y, N(1) * N(2), 1);
end
