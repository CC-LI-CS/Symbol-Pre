function toe=get_Tseries(alpha,msize)
toe=zeros(msize+1,1);toe(1)=-1;
for k=2:msize+1
   toe(k)=(1-(alpha+1)./(k-1))*toe(k-1); 
end
end