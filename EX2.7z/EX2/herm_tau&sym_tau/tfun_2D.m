function y = tfun_2D(lam,tv,n)
V=reshape(tv,n,n);
t1t=sqrt(2/(n+1))*dst(sqrt(2/(n+1))*dst(V).').';
vout=t1t(:);

vin=lam.*vout;
V=reshape(vin,n,n);
t1t=sqrt(2/(n+1))*dst(sqrt(2/(n+1))*dst(V).').';
y=t1t(:);
