function C = reshape(~,~,~)
%RESHAPE Change size of a smcirc matrix.
%
%   reshaping a smcirc matrix is meaningless.

%  Michela Redivo-Zaglia, University of Padova, Italy
%       Email: Michela.RedivoZaglia@unipd.it
%  Giuseppe Rodriguez, University of Cagliari, Italy
%       Email: rodriguez@unica.it
%
%  Last revised January 7, 2011

error('Reshaping a smcirc matrix is meaningless.')
