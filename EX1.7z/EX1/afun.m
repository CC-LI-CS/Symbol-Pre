function y = afun(cA,rA,n,av) 
%t is a vector of 2n-1 dimention concluding the first column and the first
%row of Toeplitz matrix
% A=theta*(Dl*Tl-Dr*Tr)+(1-theta)*(Dr*Tl'-Dl*Tr')
% A=v*I+d1*L+d2*L'
%% Tl*v & Tl'*v
% n=2^3-1
% cA=randn(n,1)
% rA=[cA(1) randn(1,n-1)]
%A=toeplitz(cA,rA)
% v1=randn(n,1)
v=[av;zeros(n,1)];
rA=flip(rA);
cTC=[cA;0;rA(1:n-1)'];
Laml=fft(cTC);
y=ifft(Laml.*fft(v));
y=flip(y(1:n));
% y2=A*v1
% %% 
% % ctl=[q0;q(1:N-1)];
% % rtl=[q0 zeros(1,N-1)];
% tl=[cA;rA(2:N)'];%2n-1
% % tlT=[rtl';ctl(2:N)];
% zl=[tl(1:N);0;tl(end:-1:N+1)];
% zlT=[tlT(1:N);0;tlT(end:-1:N+1)];
% Laml=fft(zl);
% LamlT=fft(zlT);
% v=[v;zeros(N,1)];
% yl=ifft(Laml.*fft(v));
% ylT=ifft(LamlT.*fft(v));
% yl=yl(1:N);
% ylT=ylT(1:N);
% 
% %% Tr*v & Tr'*v 
% % Tr=toeplitz(q,[q(1) q0 zeros(1,N-2)]);
% ctr=q;
% rtr=[q(1) q0 zeros(1,N-2)];
% tr=[ctr;rtr(2:N)'];
% trT=[rtr';ctr(2:N)];
% zr=[tr(1:N);0;tr(end:-1:N+1)];
% zrT=[trT(1:N);0;trT(end:-1:N+1)];
% Lamr=fft(zr);
% LamrT=fft(zrT);
% % v=[v;zeros(N,1)];
% yr=ifft(Lamr.*fft(v));
% yrT=ifft(LamrT.*fft(v));
% yr=yr(1:N);
% yrT=yrT(1:N);
% %% A*V
% % A=theta*(Dl*Tl-Dr*Tr)+(1-theta)*(Dr*Tl'-Dl*Tr')
% y=theta*(dl.*yl-dr.*yr)+(1-theta)*(dr.*ylT-dl.*yrT);
% end