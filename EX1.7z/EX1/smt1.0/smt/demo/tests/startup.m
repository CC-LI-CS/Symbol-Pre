% add the smt directory to the path
% should work on both unix and windows
str = pwd;
ks = strfind( str, '/');
kbs = strfind( str, '\');
if ~isempty(ks)
    str = str(1:ks(end-1)-1);
elseif ~isempty(kbs)
    str = str(1:kbs(end-1)-1);
end
addpath(str)
clear str ks kbs
