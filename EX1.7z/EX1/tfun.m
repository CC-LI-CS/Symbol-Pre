% % function y = tfun(n,dl,Taoc,Dc,tv)
% n=2^3-1
% Taoc=randn(n,1)
% cT2=randn(n,1)
% T2=toeplitz(cT2)
% %% hankel matrix is construced by SPD T2
% cHC=[cT2(3:n)' 0 0]';
% rHC=fliplr(cHC');
% HC=hankel(cHC,rHC)
% % tau=T2-HC
% 
%  %% construct Tau
% cTau=cT2-cHC %the first column of Tau
%  Tau=T2-HC
% for j=1:n
%     Dc(j)=sqrt(2/(n+1))*sin((pi*j)/(n+1));
% end
% Dc=Dc';
% 
% Lam=1./((1./Dc).*(sqrt(2/(n+1))*dst(Taoc)))
% 
% e=eig(inv(Tau))
% % y=Lam.*(sqrt(2/(n+1))*dst((1./dl).*tv));
% % y=sqrt(2/(N+1))*dst(y);
% % 
function y = tfun(n,cT,tv)
% function y = tfun(n,cT,cTau,tv)
%% 1D DST for a symmetric toeplitz matrix
%% 1D DST for a symmetric toeplitz matrix
%% compute inv(P)*v
%% Dc is the first column of Sn
Dc=zeros(n,1);
for j=1:n
    Dc(j)=sqrt(2/(n+1))*sin((pi*j)/(n+1));
end
Lam1=(1./Dc).*(sqrt(2/(n+1))*dst(cT));
% Lam2=(1./Dc).*(sqrt(2/(n+1))*dst(cTau));
% % (1./((d1-d2)^2*Lam1.^alpha+d1*d2*Lam2.^2+mu*(d1+d2)*Lam2+mu^2*ones(n,1))).^(0.5)
Inv_Lam=(1./(Lam1.^2+Lam1.^3)).^(0.5);
% Inv_Lam=1./((1./Dc).*(sqrt(2/(n+1))*dst(cTau)));
y1=Inv_Lam.*(sqrt(2/(n+1))*dst(tv));
y=sqrt(2/(n+1))*dst(y1);
end

