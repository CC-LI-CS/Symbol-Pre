function w=wfun(alpha,n)
r=alpha;
w=[];
for k=0:n-1
w(k+1)=(((-1)^k)*gamma(1+r))/(gamma(1+(r/2)-k)*gamma(1+(r/2)+k)); % the 2nd order

end
w=w';
end