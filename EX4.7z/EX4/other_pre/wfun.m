function w=wfun(alpha,n)
g0=1;
g=zeros(n,1);
g(1)=-alpha;
for j=1:n-1
g(j+1)=(1-(alpha+1)/(j+1))*g(j);
end
 w=g;
 w(1)=2*g(1);
 w(2)=g0+g(2);

end