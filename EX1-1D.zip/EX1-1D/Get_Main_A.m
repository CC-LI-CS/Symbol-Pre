function [c,r] = Get_Main_A(n)
%GET_MAIN_A Summary of this function goes here
%   Detailed explanation goes here

c = zeros(n,1);
r = zeros(n,1);

c(1) = 2;
c(2) = 3/2;

r(1) = 2;
r(2) = -7/2;

for i = 3:n
    c(i) = (2*((-1)^(i-1))*(1-2*(i-1)^2))/((i-1)*((i-1)^2 - 1));
%     r(i) = (2*((-1)^(i-1))*(1-2*(i-1)^2))/((i-1)*((i-1)^2 - 1));
end

for i = -3:-1:-n
    r(abs(i)) = (2*((-1)^(i+1))*(1-2*(i+1)^2))/((i+1)*((i+1)^2 - 1));
end



end

