====================================================================
Numerical tests
====================================================================

The files in the this directory reproduce the numerical tests
reported in the paper
	M. Redivo-Zaglia, G. Rodriguez
	smt: a Matlab toolbox for structured matrices

To replicate the tests it is necessary to run the following commands

test1		% to create Figure 1
test2		% to create Figure 2
test3		% to create Figure 3
test4		% to create Table 6

