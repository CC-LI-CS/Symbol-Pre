% add the smt directory to the path
% should work both on unix and windows
str = pwd;
ks = strfind( str, '/');
kbs = strfind( str, '\');
if ~isempty(ks)
    str = str(1:ks(end)-1);
elseif ~isempty(kbs)
    str = str(1:kbs(end)-1);
end
addpath(str)
clear str ks kbs
