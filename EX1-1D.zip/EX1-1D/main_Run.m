function [iv,tv,rv] = main_Run
% Example 1, Table 5.1 from J. Pestana, Preconditioners for symmetrized
% Toeplitz and multilevel Toeplitz matrices, 2018.
%
% Outputs:  iv: array of iteration numbers
%           tv: array of CPU times
%           rv: array of relative residuals
%
% J. Pestana, July 26, 2018

%% Setup %%%
fid = fopen('Ex1_AR.txt','w+'); % Open file for table
circtype = 'optimal'; % Use optimal circulant preconditioner
nvec = 2.^(12)-1;  % Dimensions of problems
% Set up arrays to store iterations, etc.
n_time = length(nvec);
iv = zeros(n_time,6);
tv = zeros(n_time,6);
rv = zeros(n_time,6);
rng('default'); % Set random number generator

%% Main computations
for j = 1:n_time
    n = nvec(j);
    disp(n)
    lev = log2(n+1);
    mglev = lev-4;
    disp(n)
    fprintf('Building matrix...')
    [cA,rA] = Get_Main_A(n);
    size(cA)
    rA=rA';
    c=cA;r=rA;
    Tsmt = smtoep(c,r);

    b = randn(n,1); b = b/norm(b);  % RHS
    tol = 1e-8;                     % Iterative solver tolerance
    x0 = ones(n,1)/sqrt(n);         % Intial guess

    %% Set up preconditioners


    %  %% MINRES with exact preconditioner
    [ca,ra] = Ex1_Gen_Toep_Abs_F(n);
    ra(1) = ca(1);    fprintf('MINRES with multigrid preconditioner...')
    tic;
    Yb = b(n:-1:1);                 % Apply Y to b
    [diagel,Asm,Ac] = vcycle_fastmv_setup(ca,ra,mglev);
    [~,~,~,iv(j,5),resmp] = minres(@(av)afun(cA,rA,n,av),Yb,tol,n,@(y)vcycle_fastmv_nr(diagel,Asm,Ac,y,2,2,mglev,0.5),[],x0);
    tv(j,5) = toc;
    rv(j,5) = resmp(end);
    fprintf('Done\n');


    %% MINRES with circulant preconditioner
    fprintf('MINRES with circulant preconditioner...')
    tic;
    Csmt = smtcprec(circtype,Tsmt);
    CPsmt =  smcirc(ifft(abs(eig(Csmt))));
    Yb = b(n:-1:1);                 % Apply Y to b
    [~,~,~,iv(j,2),resmpc] = minres(@(av)afun(cA,rA,n,av),Yb,tol,n,@(y)capply(CPsmt,y),[],x0);
    tv(j,2) = toc;
    rv(j,2) = resmpc(end);
    fprintf('Done\n');

    %% MINRES with tridiagonal preconditioner
    fprintf('MINRES with tridiagonal preconditioner...')
    tic;
    P = gallery('tridiag',n,-1,2,-1);
    Yb = b(n:-1:1);                 % Apply Y to b
    [~,~,~,iv(j,3),resmp] = minres(@(av)afun(cA,rA,n,av),Yb,tol,n,P,[],x0);
    tv(j,3) = toc;
    rv(j,3) = resmp(end);
    fprintf('Done\n');

    %% MINRES WITH THE PROPOSED preconditioner
    cT=[2;-1;zeros(n-2,1)]; % the first column of cT
    fprintf('MINRES WITH the preposed preconditioner...')
    tic;
    Yb = b(n:-1:1);
    [~, ~, ~,iv(j,6), reslp] = minres(@(av)afun(cA,rA,n,av),Yb,tol,n,@(tv)tfun(n,cT,tv),[],x0);
    tv(j,6) = toc;
    rv(j,6) = reslp(end);
    fprintf('Done\n');
    save Ex1_AR iv tv rv

    %% Add iterations and timings to table
    fprintf(fid,'%i & %i & (%3.2g) & %i & (%3.2g) & %i & (%3.2g) & %i & (%3.2g) & %i & (%3.2g) & %i & (%3.2g) \\\\\n',n,iv(j,1),tv(j,1),iv(j,2),tv(j,2),iv(j,3),tv(j,3),iv(j,4),tv(j,4),iv(j,5),tv(j,5),iv(j,6),tv(j,6));

end
fclose(fid);

    function y = capply(Csmt,x)
        y = mldivide(Csmt,x);
    end

end
